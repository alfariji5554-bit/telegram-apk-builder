# Telegram Builder — Node.js / Termux

## Features
- Send an Android project `.zip` as a Telegram document → temporary GitHub Release → GitHub Actions → `assembleDebug` → APK sent back.
- Send a plain `http://` or `https://` message → generated WebView Android project → APK sent back.
- `/deploy` → choose Vercel or Netlify → send website `.zip` → deploy from Termux.
- `/status`, `/cancel`.
- Node.js only for the bot. No Python.

## ZIP limits
Default is 18 MB because Telegram Bot API currently allows bots to download files up to 20 MB. A local Telegram Bot API server can remove that download limit. The builder still depends on GitHub/API and runner limits.

## Security
- Set `ALLOWED_USER_IDS`.
- Never commit `.env`.
- Use a fine-grained GitHub token with Contents: write and Actions: write on the builder repo.
- Vercel uses an Access Token.
- Netlify uses a Personal Access Token.
- APK output is a debug APK. Production release signing is a separate keystore setup.

## Commands
/start
/help
/deploy
/status
/cancel

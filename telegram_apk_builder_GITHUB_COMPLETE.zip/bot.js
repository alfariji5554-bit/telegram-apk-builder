require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");
const AdmZip = require("adm-zip");

const cfg = {
  token: process.env.BOT_TOKEN,
  allowed: new Set((process.env.ALLOWED_USER_IDS || "").split(",").map(s=>s.trim()).filter(Boolean)),
  ghToken: process.env.GITHUB_TOKEN,
  ghOwner: process.env.GITHUB_OWNER,
  ghRepo: process.env.GITHUB_REPO,
  ghBranch: process.env.GITHUB_BRANCH || "main",
  vercelToken: process.env.VERCEL_TOKEN,
  vercelTeamId: process.env.VERCEL_TEAM_ID || "",
  netlifyToken: process.env.NETLIFY_AUTH_TOKEN,
  netlifySiteId: process.env.NETLIFY_SITE_ID || "",
  maxZip: Number(process.env.MAX_ZIP_MB || 20) * 1024 * 1024,
  work: path.resolve(process.env.WORK_DIR || "./data")
};
if (!cfg.token) throw new Error("BOT_TOKEN belum diisi.");
if (!cfg.ghToken || !cfg.ghOwner || !cfg.ghRepo) throw new Error("Konfigurasi GitHub belum lengkap.");

const bot = new TelegramBot(cfg.token, { polling: true });
const jobs = new Map();
fs.mkdirSync(cfg.work, {recursive:true});

function allowed(msg) {
  return !cfg.allowed.size || cfg.allowed.has(String(msg.from?.id));
}
async function guard(msg) {
  if (!allowed(msg)) { await bot.sendMessage(msg.chat.id, "⛔ Akses ditolak."); return false; }
  return true;
}
function id(){ return crypto.randomBytes(8).toString("hex"); }
function sh(cmd,args,cwd,env={}) {
  return new Promise((resolve,reject)=>{
    const p=spawn(cmd,args,{cwd,env:{...process.env,...env},stdio:["ignore","pipe","pipe"]});
    let out="",err="";
    p.stdout.on("data",d=>out+=d); p.stderr.on("data",d=>err+=d);
    p.on("error",reject); p.on("close",code=>code===0?resolve(out.trim()):reject(new Error(`${cmd} ${args.join(" ")}\n${err.slice(-5000)}`)));
  });
}
async function gh(method, p, body) {
  const r=await fetch(`https://api.github.com${p}`,{
    method, headers:{
      "Accept":"application/vnd.github+json",
      "Authorization":`Bearer ${cfg.ghToken}`,
      "X-GitHub-Api-Version":"2026-03-10",
      ...(body?{"Content-Type":"application/json"}:{})
    }, body: body?JSON.stringify(body):undefined
  });
  const text=await r.text(); let data={}; try{data=JSON.parse(text)}catch{}
  if(!r.ok) throw new Error(`GitHub ${r.status}: ${data.message||text.slice(0,700)}`);
  return data;
}
async function ghCreateRelease(tag) {
  return gh("POST",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/releases`,{
    tag_name:tag, name:`telegram-builder-${tag}`, body:"Temporary builder input release", draft:false, prerelease:true
  });
}
async function ghUploadReleaseAsset(releaseId,name,buf) {
  const r=await fetch(`https://uploads.github.com/repos/${cfg.ghOwner}/${cfg.ghRepo}/releases/${releaseId}/assets?name=${encodeURIComponent(name)}`,{
    method:"POST",
    headers:{"Accept":"application/vnd.github+json","Authorization":`Bearer ${cfg.ghToken}`,"X-GitHub-Api-Version":"2026-03-10","Content-Type":"application/zip"},
    body:buf
  });
  const text=await r.text(); let data={}; try{data=JSON.parse(text)}catch{}
  if(!r.ok)throw new Error(`GitHub asset upload ${r.status}: ${data.message||text.slice(0,700)}`);
  return data;
}
async function ghDeleteRelease(releaseId) {
  try{await gh("DELETE",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/releases/${releaseId}`)}catch{}
}
async function netlifyCreateSite(name){
  const r=await fetch("https://api.netlify.com/api/v1/sites",{
    method:"POST",
    headers:{"Authorization":`Bearer ${cfg.netlifyToken}`,"Content-Type":"application/json"},
    body:JSON.stringify({name:`telegram-${name}`})
  });
  const t=await r.text();let d={};try{d=JSON.parse(t)}catch{}
  if(!r.ok)throw new Error(`Netlify ${r.status}: ${d.message||t.slice(0,700)}`);
  return d;
}

async function dispatch(workflow,inputs) {
  await gh("POST",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/workflows/${encodeURIComponent(workflow)}/dispatches`,{ref:cfg.ghBranch,inputs});
  const wanted=inputs.job_id;
  for(let i=0;i<12;i++){
    await new Promise(r=>setTimeout(r,2000));
    const d=await gh("GET",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/workflows/${encodeURIComponent(workflow)}/runs?event=workflow_dispatch&branch=${encodeURIComponent(cfg.ghBranch)}&per_page=20`);
    const run=(d.workflow_runs||[]).find(x=>String(x.run_name||"").includes(wanted)||String(x.display_title||"").includes(wanted));
    if(run)return run.id;
  }
  throw new Error("Workflow sudah dipanggil tetapi run belum terlihat. Cek Actions.");
}
async function runInfo(runId){return gh("GET",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/runs/${runId}`)}
async function findArtifact(runId,prefix){
  const d=await gh("GET",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/runs/${runId}/artifacts?per_page=100`);
  return (d.artifacts||[]).find(a=>a.name.startsWith(prefix)&&!a.expired);
}
async function downloadArtifact(artifactId,dest){
  const r=await fetch(`https://api.github.com/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/artifacts/${artifactId}/zip`,{headers:{
    "Accept":"application/vnd.github+json","Authorization":`Bearer ${cfg.ghToken}`,"X-GitHub-Api-Version":"2026-03-10"
  }});
  if(!r.ok)throw new Error(`Artifact download HTTP ${r.status}`);
  const b=Buffer.from(await r.arrayBuffer()); await fsp.writeFile(dest,b);
}
async function waitRun(runId,kind,chatId) {
  for(let i=0;i<180;i++){
    const r=await runInfo(runId);
    if(r.status==="completed"){
      if(r.conclusion!=="success") throw new Error(`Build gagal (${r.conclusion}).\n${r.html_url}`);
      const a=await findArtifact(runId,kind==="apk"?"apk-":"site-");
      if(!a)throw new Error("Build sukses tetapi artifact tidak ditemukan.");
      return {run:r,artifact:a};
    }
    if(i%6===0) await bot.sendMessage(chatId,`⏳ Build masih berjalan… ${r.status}\nRun: ${r.html_url}`);
    await new Promise(x=>setTimeout(x,10000));
  }
  throw new Error("Timeout 30 menit. Cek GitHub Actions.");
}
async function sendApk(chatId,artifact){
  const z=path.join(cfg.work,`${artifact.id}.zip`), out=path.join(cfg.work,`${artifact.id}-apk.zip`), ap=path.join(cfg.work,`${artifact.id}.apk`);
  await downloadArtifact(artifact.id,z);
  const zip=new AdmZip(z); const entry=zip.getEntries().find(e=>e.entryName.toLowerCase().endsWith(".apk"));
  if(!entry)throw new Error("Artifact tidak berisi APK.");
  await fsp.writeFile(ap,entry.getData());
  await bot.sendDocument(chatId,ap,{caption:"✅ APK berhasil dibuat."});
  await Promise.allSettled([fsp.rm(z,{force:true}),fsp.rm(ap,{force:true})]);
}
async function processApkZip(msg,fileId,fileName){
  const chatId=msg.chat.id, job=id(), tag=`builder-${job}`, asset=`${job}.zip`;
  let release=null;
  try{
    const meta=await bot.getFile(fileId);
    if(meta.file_size && meta.file_size>cfg.maxZip)throw new Error(`ZIP terlalu besar. Batas ${Math.floor(cfg.maxZip/1048576)} MB.`);
    const link=await bot.getFileLink(fileId);
    const zipBuf=Buffer.from(await (await fetch(link)).arrayBuffer());
    if(zipBuf.length>cfg.maxZip)throw new Error(`ZIP terlalu besar. Batas ${Math.floor(cfg.maxZip/1048576)} MB.`);
    release=await ghCreateRelease(tag);
    await ghUploadReleaseAsset(release.id,asset,zipBuf);
    jobs.set(chatId,{job,kind:"apk",releaseId:release.id,tag,asset});
    await bot.sendMessage(chatId,"📦 ZIP diterima. Upload ke temporary GitHub Release selesai. Compile APK dimulai…");
    const runId=await dispatch("build-zip.yml",{release_tag:tag,asset_name:asset,job_id:job});
    jobs.get(chatId).runId=runId;
    const result=await waitRun(runId,"apk",chatId);
    await sendApk(chatId,result.artifact);
    await bot.sendMessage(chatId,`🎉 Selesai.\nRun: ${result.run.html_url}`);
  } finally {
    if(release?.id) await ghDeleteRelease(release.id);
    jobs.delete(chatId);
  }
}
async function buildUrl(chatId,url){
  const u=new URL(url);
  if(!["http:","https:"].includes(u.protocol))throw new Error("URL harus http:// atau https://");
  const job=id(); jobs.set(chatId,{job,kind:"url"});
  await bot.sendMessage(chatId,`🌐 URL diterima:\n${url}\n\n⏳ Membuat project WebView dan compile APK…`);
  try{
    const runId=await dispatch("build-url.yml",{url,job_id:job});jobs.get(chatId).runId=runId;
    const result=await waitRun(runId,"apk",chatId);await sendApk(chatId,result.artifact);
    await bot.sendMessage(chatId,`🎉 APK URL selesai.\nRun: ${result.run.html_url}`);
  } finally { jobs.delete(chatId); }
}
async function extractZip(buf,dir){
  const zip=new AdmZip(buf); zip.extractAllTo(dir,true);
  const entries=await fsp.readdir(dir);
  if(entries.length===1){
    const one=path.join(dir,entries[0]);
    if((await fsp.stat(one)).isDirectory()) return one;
  }
  return dir;
}
async function deployZip(chatId,fileId,provider){
  if(provider==="vercel"&&!cfg.vercelToken)throw new Error("VERCEL_TOKEN belum diisi.");
  if(provider==="netlify"&&!cfg.netlifyToken)throw new Error("NETLIFY_AUTH_TOKEN belum diisi.");
  const job=id(), dir=path.join(cfg.work,job); await fsp.mkdir(dir,{recursive:true});
  const link=await bot.getFileLink(fileId), buf=Buffer.from(await (await fetch(link)).arrayBuffer());
  if(buf.length>cfg.maxZip)throw new Error(`ZIP terlalu besar. Batas ${Math.floor(cfg.maxZip/1048576)} MB.`);
  const project=await extractZip(buf,dir);
  await bot.sendMessage(chatId,`🚀 Deploy ${provider==="vercel"?"Vercel":"Netlify"} dimulai…`);
  let out;
  if(provider==="vercel"){
    const args=[project,"--prod","--yes","--token",cfg.vercelToken];
    if(cfg.vercelTeamId)args.push("--scope",cfg.vercelTeamId);
    out=await sh("npx",["--yes","vercel@latest",...args]);
    const lines=out.split(/\r?\n/).filter(Boolean); const url=lines[lines.length-1];
    await bot.sendMessage(chatId,`✅ Vercel deploy selesai:\n${url}`);
  }else{
    let siteId=cfg.netlifySiteId;
    if(!siteId){ const site=await netlifyCreateSite(job); siteId=site.id; }
    let args=["--yes","netlify-cli@latest","deploy","--prod","--site",siteId,"--build","--dir",project];
    out=await sh("npx",args,project,{NETLIFY_AUTH_TOKEN:cfg.netlifyToken});
    const url=(out.match(/Website URL:\s*(\S+)/i)||[])[1] || (out.match(/Unique deploy URL:\s*(\S+)/i)||[])[1] || (out.match(/https:\/\/[^\s]+\.netlify\.app/i)||[])[0];
    await bot.sendMessage(chatId,`✅ Netlify deploy selesai.${url?`\n${url}`:""}`);
  }
  await fsp.rm(dir,{recursive:true,force:true});
}
function deployKeyboard(){return {reply_markup:{inline_keyboard:[
  [{text:"▲ Deploy ke Vercel",callback_data:"deploy_vercel"},{text:"◆ Deploy ke Netlify",callback_data:"deploy_netlify"}]
]}}}

bot.onText(/^\/start$/,(msg)=>guard(msg).then(ok=>ok&&bot.sendMessage(msg.chat.id,
"🤖 Telegram Builder\n\n"+
"• Kirim ZIP → bot build menjadi APK\n"+
"• Kirim URL biasa → otomatis URL → APK\n"+
"• /deploy → pilih Vercel/Netlify, lalu kirim ZIP website\n\n"+
"/status — status job terakhir\n/cancel — batalkan workflow GitHub\n/help — bantuan")));
bot.onText(/^\/help$/,(msg)=>guard(msg).then(ok=>ok&&bot.sendMessage(msg.chat.id,
"📖 Cara pakai:\n\n1) ZIP Android → kirim sebagai Document.\n2) URL → kirim URL saja.\n3) /deploy → pilih provider → kirim ZIP website.\n\nAPK yang dikirim adalah debug APK; untuk release signing perlu konfigurasi keystore terpisah.")));
bot.onText(/^\/deploy$/,(msg)=>guard(msg).then(ok=>ok&&bot.sendMessage(msg.chat.id,"Pilih target deployment:",deployKeyboard())));
bot.onText(/^\/status$/,(msg)=>guard(msg).then(async ok=>{
  if(!ok)return; const j=jobs.get(msg.chat.id); if(!j)return bot.sendMessage(msg.chat.id,"Belum ada job.");
  if(!j.runId)return bot.sendMessage(msg.chat.id,`Job ${j.job} sedang diproses sebelum run dibuat.`);
  try{const r=await runInfo(j.runId);await bot.sendMessage(msg.chat.id,`Job ${j.job}\nStatus: ${r.status}\nConclusion: ${r.conclusion||"-"}\n${r.html_url}`)}
  catch(e){await bot.sendMessage(msg.chat.id,`❌ ${e.message}`)}
}));
bot.onText(/^\/cancel$/,(msg)=>guard(msg).then(async ok=>{
  if(!ok)return;const j=jobs.get(msg.chat.id);if(!j?.runId)return bot.sendMessage(msg.chat.id,"Tidak ada workflow aktif.");
  try{await gh("POST",`/repos/${cfg.ghOwner}/${cfg.ghRepo}/actions/runs/${j.runId}/cancel`);await bot.sendMessage(msg.chat.id,"🛑 Permintaan cancel dikirim.");}
  catch(e){await bot.sendMessage(msg.chat.id,`❌ ${e.message}`)}
}));

bot.on("callback_query",async q=>{
  const msg=q.message;if(!allowed(msg)){await bot.answerCallbackQuery(q.id,{text:"Akses ditolak"});return;}
  if(q.data==="deploy_vercel"||q.data==="deploy_netlify"){
    jobs.set(msg.chat.id,{job:id(),kind:"deploy",provider:q.data==="deploy_vercel"?"vercel":"netlify",waitingZip:true});
    await bot.answerCallbackQuery(q.id);
    await bot.sendMessage(msg.chat.id,`Target: ${q.data==="deploy_vercel"?"Vercel ▲":"Netlify ◆"}\n\nSekarang kirim ZIP website sebagai Document.`);
  }
});

bot.on("document",async msg=>{
  if(!await guard(msg))return;
  const doc=msg.document;const name=(doc.file_name||"").toLowerCase();
  if(!name.endsWith(".zip"))return bot.sendMessage(msg.chat.id,"❌ Kirim file .zip.");
  try{
    const j=jobs.get(msg.chat.id);
    if(j?.kind==="deploy"&&j.waitingZip){
      await deployZip(msg.chat.id,doc.file_id,j.provider);jobs.delete(msg.chat.id);return;
    }
    await processApkZip(msg,doc.file_id,doc.file_name);
  }catch(e){await bot.sendMessage(msg.chat.id,`❌ ${e.message}`)}
});

bot.on("message",async msg=>{
  if(!msg.text||msg.text.startsWith("/"))return;
  if(!await guard(msg))return;
  const text=msg.text.trim();
  if(/^https?:\/\/\S+$/i.test(text)){
    try{await buildUrl(msg.chat.id,text)}catch(e){await bot.sendMessage(msg.chat.id,`❌ ${e.message}`)}
    return;
  }
  if(text.toLowerCase()==="deploy"){
    await bot.sendMessage(msg.chat.id,"Pilih target deployment:",deployKeyboard());
    return;
  }
  await bot.sendMessage(msg.chat.id,"Kirim ZIP Android untuk build APK, atau kirim URL http/https langsung. Untuk website: /deploy.");
});

bot.on("polling_error",e=>console.error("polling_error:",e.message));
console.log("Telegram Builder Node.js aktif.");

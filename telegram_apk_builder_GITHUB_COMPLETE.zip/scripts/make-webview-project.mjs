import fs from "node:fs";
import path from "node:path";
const url=process.argv[2];
try{const u=new URL(url);if(!["http:","https:"].includes(u.protocol))throw new Error("bad")}catch{process.exit(2)}
const root=path.resolve("generated-app");
fs.mkdirSync(path.join(root,"app/src/main/java/com/example/urlapp"),{recursive:true});
fs.mkdirSync(path.join(root,"app/src/main/res/values"),{recursive:true});
const esc=url.replaceAll("\\","\\\\").replaceAll('"','\\"');
fs.writeFileSync(path.join(root,"settings.gradle.kts"),`pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name="UrlApp"
include(":app")
`);
fs.writeFileSync(path.join(root,"build.gradle.kts"),`plugins { id("com.android.application") version "9.3.0" apply false }
`);
fs.writeFileSync(path.join(root,"gradle.properties"),`org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8
`);
fs.writeFileSync(path.join(root,"app/build.gradle.kts"),`plugins { id("com.android.application") }
android {
  namespace="com.example.urlapp"
  compileSdk=36
  defaultConfig { applicationId="com.example.urlapp"; minSdk=23; targetSdk=36; versionCode=1; versionName="1.0" }
  buildTypes { release { isMinifyEnabled=false } }
}
`);
fs.writeFileSync(path.join(root,"app/src/main/res/values/styles.xml"),`<resources><style name="AppTheme" parent="@android:style/Theme.Material.Light.NoActionBar"><item name="android:colorAccent">#1565C0</item></style></resources>`);
fs.writeFileSync(path.join(root,"app/src/main/AndroidManifest.xml"),`<manifest xmlns:android="http://schemas.android.com/apk/res/android">
<uses-permission android:name="android.permission.INTERNET"/>
<application android:theme="@style/AppTheme" android:label="Web App">
<activity android:name=".MainActivity" android:screenOrientation="portrait" android:exported="true">
<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
</activity></application></manifest>`);
fs.writeFileSync(path.join(root,"app/src/main/java/com/example/urlapp/MainActivity.java"),`package com.example.urlapp;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 WebView webView;
 @Override public void onCreate(Bundle b){super.onCreate(b);webView=new WebView(this);setContentView(webView);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient());webView.loadUrl("${esc}");}
 @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
`);
fs.writeFileSync(path.join(root,"gradlew"),`#!/bin/sh
set -eu
D="$HOME/.gradle/telegram-builder/gradle-9.5.0"
if [ ! -x "$D/bin/gradle" ]; then
 mkdir -p "$HOME/.gradle/telegram-builder"
 A="$HOME/.gradle/telegram-builder/gradle.zip"
 curl -fsSL "https://services.gradle.org/distributions/gradle-9.5.0-bin.zip" -o "$A"
 rm -rf "$D"
 unzip -q "$A" -d "$HOME/.gradle/telegram-builder"
 rm -f "$A"
fi
exec "$D/bin/gradle" "$@"
`);
fs.chmodSync(path.join(root,"gradlew"),0o755);
